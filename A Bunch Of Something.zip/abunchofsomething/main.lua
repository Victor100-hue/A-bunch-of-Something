-- name: \\#blueee\\a bunch of something
-- description: this is a bunch of random stuff in one mod, i hope you like it.\n\nsay /act99 to go to act 99 of your current level.\nsay /act0 to go to act 0 of your current level.\n\nsay /enter pc to warp to "Peach's Castle".\n\nmade by watchr/defacube

-- replaces castle music with wrinkly 64 which is sometimes used in beta hacks idk.\n\nbtw i know you stole this from the tmp folder cuz this mod is private for no actual reason lmfao

-- function warp()
-- if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == 6) then
--     stop_background_music(4)
-- else
--     smlua_audio_utils_replace_sequence(0x04, 0x0E, 75, "04_Seq_custom")
-- end
---@param o Object
--LEVEL_HOLY_YELLOW_SWITCH_PALACE = level_register("level_holy_yellow_switch_palace_entry", COURSE_NONE, "Holy Yellow Switch Palace", "palace", 20000, 0x28, 0x28, 0x28)

-- dialogs
smlua_text_utils_dialog_replace(DIALOG_113, 1, 5, 30, 200, "THESE WORLDS ARE\
GETTING STRANGER AND\
STRANGER! I COULD'VE\
SWORN THIS PLACE WAS\
DIFFERENT!")

-- definitions
local nearLObject = false
local closetoLObject = true
local silverStarTimerOn = false
local silverStarTimer = 0
gPlayerSyncTable[0].previouslyBeenInBigMansion = false
gPlayerSyncTable[0].silverStars = 0
gPlayerSyncTable[0].maxSilverStars = 999
gPlayerSyncTable[0].eerieHMCstar = false

-- music
smlua_audio_utils_replace_sequence(36, 0x0E, 75, "crescentcastle")
smlua_audio_utils_replace_sequence(37, 34, 75, "fieldofbombs")
smlua_audio_utils_replace_sequence(38, 0x0E, 75, "slowcastle")
smlua_audio_utils_replace_sequence(39, 0x0E, 75, "castle")
smlua_audio_utils_replace_sequence(40, 34, 75, "BATTLEFIELD")
smlua_audio_utils_replace_sequence(41, 17, 75, "wec")
smlua_audio_utils_replace_sequence(42, 19, 75, "invertedcg")
smlua_audio_utils_replace_sequence(43, 37, 75, "funnymaze")
smlua_audio_utils_replace_sequence(44, 13, 75, "slidee")
smlua_audio_utils_replace_sequence(45, 19, 75, "minorminordocks")
smlua_audio_utils_replace_sequence(46, 11, 75, "coldcoldhill")
smlua_audio_utils_replace_sequence(47, 19, 75, "04_Seq_custom")
smlua_audio_utils_replace_sequence(48, 17, 75, "game_over")
smlua_audio_utils_replace_sequence(49, 12, 75, "silverstar")
smlua_audio_utils_replace_sequence(50, 34, 75, "03_level_grass")
smlua_audio_utils_replace_sequence(51, 34, 75, "strangebattlefield")
smlua_audio_utils_replace_sequence(52, 21, 75, "underground")

-- levels
LEVEL_EERIEGROUNDS = level_register("level_eeriegrounds_entry", COURSE_NONE, "Eeriegrounds", "eg", 28000, 40, 40, 40)
LEVEL_WEIRDYARD = level_register("level_weirdyard_entry", COURSE_NONE, "castle_courtyard", "wc", 28000, 40, 40, 40)
LEVEL_BOB_Z64 = level_register("level_bob_z64_entry", COURSE_NONE, "bob.z64", "bz64", 28000, 0x28, 0x28, 0x28)
LEVEL_FAKE_GROUNDS = level_register("level_fake_grounds_entry", COURSE_NONE, "castle_grounds", "wg", 28000, 0x28, 0x28, 0x28)
LEVEL_FAKE_LLL = level_register("level_fake_lll_entry", COURSE_NONE, "LETHAL LAVA PURGATORY", "llp", 20000, 0x28, 0x28, 0x28)
LEVEL_CCH = level_register("level_cch_entry", COURSE_NONE, "Cold, Cold Hill", "cch", 20000, 0x28, 0x28, 0x28)
LEVEL_DDW = level_register("level_ddw_entry", COURSE_NONE, "Dry, Dry World", "ddw", 20000, 0x28, 0x28, 0x28)
LEVEL_INVERTED_CASTLE_GROUNDS = level_register("level_invertedcg_entry", COURSE_NONE, "sdnuorgeltsaC", "invertedcg", 20000, 0x28, 0x28, 0x28)
LEVEL_TOADS_LOBBY = level_register("level_toadslobby_entry", COURSE_NONE, "Toad's Lobby", "tl", 20000, 0x28, 0x28, 0x28)
LEVEL_UD_BOB = level_register("level_udbob_entry", COURSE_NONE, "Battlefield", "udbob", 20000, 0x28, 0x28, 0x28)
LEVEL_CREEPY_JRB = level_register("level_creepyjrb_entry", COURSE_NONE, "jolly", "creepyjrb", 20000, 0x28, 0x28, 0x28)
LEVEL_PAINTING_WARP_TEST = level_register("level_paintingwarptest_entry", COURSE_NONE, "big_mansion", "pwtest", 20000, 0x28, 0x28, 0x28)
LEVEL_EERIE_CASTLE = level_register("level_eeriecastle_entry", COURSE_NONE, "Bowser's Castle", "eeriecastle", 20000, 0x28, 0x28, 0x28)
LEVEL_BETA_BOB = level_register("level_betabob_entry", COURSE_NONE, "Bob-omb Arena", "betabob", 20000, 0x28, 0x28, 0x28)
LEVEL_EERIE_HMC = level_register("level_eeriehmc_entry", COURSE_NONE, "HAZY CAVE", "eeriehmc", 20000, 0x28, 0x28, 0x28)

-- behaviors
function lies_init(o)
        o.oFlags = (OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_COMPUTE_DIST_TO_MARIO)
        -- gGlobalSyncTable.liesObject = o
end
---@param o Object
function lies_loop(o)
        obj_set_billboard(o)
        if (dist_between_objects(o, gMarioStates[0].marioObj)) <= 2000 then
                nearLObject = true
        else
                nearLObject = false
        end
        if (dist_between_objects(o, gMarioStates[0].marioObj)) <= 600 then
                closetoLObject = true
        else
                closetoLObject = false
        end
        if (dist_between_objects(o, gMarioStates[0].marioObj)) <= 400 and (gNetworkPlayers[0].currLevelNum == LEVEL_FAKE_LLL) then
                warp_to_castle(4)
        end
        if (dist_between_objects(o, gMarioStates[0].marioObj)) <= 400 and (gNetworkPlayers[0].currLevelNum == LEVEL_EERIE_HMC) then
                gPlayerSyncTable[0].eerieHMCstar = true
                warp_to_level(LEVEL_CREEPY_JRB, 1, 0)
        end
end
function wind_init(o)
        o.oFlags = (OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_ACTIVE_FROM_AFAR)
        
end
---@param o Object
function wind_loop(o)
        play_sound(SOUND_AIR_HOWLING_WIND, gMarioStates[0].marioObj.header.gfx.cameraToObject)
        o.oPosX = gMarioStates[0].pos.x
        o.oPosY = gMarioStates[0].pos.y
        o.oPosZ = gMarioStates[0].pos.z
end
---@param o Object
function ukiki_init(o)
        o.oInteractionSubtype = INT_SUBTYPE_NPC
        o.oInteractType = INTERACT_TEXT
        o.oFlags = (OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_SET_FACE_YAW_TO_MOVE_YAW)
        bhv_bobomb_buddy_init()
        smlua_anim_util_set_animation(o, "koopa")
        o.oIntangibleTimer = 0
        o.hitboxHeight = 113
        o.hitboxRadius = 65
        o.hitboxDownOffset = 0
        o.oGravity = 2.5
        o.oFriction = 0.8
        o.oBuoyancy = 1.3
        o.oGraphYOffset = o.oGraphYOffset + 35
        timer = 0
    end
    ---@param o Object
    function ukiki_loop(o)
        bhv_bobomb_buddy_loop()
        local timer = timer + 1
        ---@type MarioState
        local m = gMarioStates[0]
        if timer == 0 then
            smlua_anim_util_set_animation(o, "koopa")
        end
        if timer == 0x3C then
            smlua_anim_util_set_animation(o, "koopa2")
        end
        if timer == 0x3C + 0x1A then
            smlua_anim_util_set_animation(o, "koopa3")
        end
        if timer == 0x3C + 0x1A + 0x22 then
            timer = 0
        end
        
        object_step()
    end
---@param o Object
function silver_star_init(o)
        o.oFlags = (OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_ACTIVE_FROM_AFAR)
end
---@param o Object
function silver_star_loop(o)
        o.oForwardVel = 40
        local pos = {x = o.oPosX, y = o.oPosY, z = o.oPosZ}
        if ((o.oPosY - 175) <= o.oFloorHeight) then
                play_sound(SOUND_GENERAL_SHORT_STAR, pos)
                o.oVelY = 40
                o.oFaceAngleYaw = math.random(0, 65536)
        end
        o.oVelY = o.oVelY - 4
        o.header.gfx.angle.y = o.header.gfx.angle.y + 0x250
        object_step()
        if (dist_between_objects(o, gMarioStates[0].marioObj) <= 175) then
                obj_mark_for_deletion(o)
                play_secondary_music(49, 25, 75, 1)
                gPlayerSyncTable[0].silverStars = gPlayerSyncTable[0].silverStars + 1
                silverStarTimerOn = true
        end
end
id_bhvLies = hook_behavior(nil, OBJ_LIST_LEVEL, true, lies_init, lies_loop, "Lies")
id_bhvWindA = hook_behavior(nil, OBJ_LIST_LEVEL, true, wind_init, wind_loop, "windA")
id_bhvTalkingKoopa = hook_behavior(nil, OBJ_LIST_LEVEL, true, ukiki_init, ukiki_loop, "talkingKoopa")
id_bhvSilverStar = hook_behavior(nil, OBJ_LIST_LEVEL, true, silver_star_init, silver_star_loop, "silverStar")
smlua_audio_utils_replace_sequence(0x23, 0x0E, 75, "35_Seq_custom")
local timer = 0
---@param m MarioState

-- misc
function mario_update(m)
        if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == LEVEL_PSS) then
                if m.actionTimer >= 600 then
                        m.health = 0xFF
                end
        end
        if silverStarTimerOn == true then
                silverStarTimer = silverStarTimer + 1
                if silverStarTimer >= 150 then
                        silverStarTimerOn = false
                        silverStarTimer = 0
                        if gPlayerSyncTable[0].silverStars == gPlayerSyncTable[0].maxSilverStars then
                                spawn_no_exit_star(gMarioStates[0].pos.x, (gMarioStates[0].pos.y + 300), gMarioStates[0].pos.z)
                        end
                end
        end
end
hook_event(HOOK_MARIO_UPDATE, mario_update)
function onhudrender()
        if nearLObject == true and (gNetworkPlayers[0].currLevelNum == LEVEL_FAKE_LLL) then
                djui_hud_set_font(FONT_HUD)
                djui_hud_set_resolution(RESOLUTION_DJUI)
                local scale = 4
                local width = djui_hud_measure_text("IT IS NOT REAL") * scale
                local x = (djui_hud_get_screen_width() - width) * 0.5
                local randval = math.random(0,1)
                local height = djui_hud_get_screen_height()
                if randval == 0 then
                        djui_hud_print_text("IT IS NOT REAL", x,height/2, scale)
                end
        end
        if nearLObject == true and (gNetworkPlayers[0].currLevelNum == LEVEL_CCH) then
                djui_hud_set_font(FONT_HUD)
                djui_hud_set_resolution(RESOLUTION_DJUI)
                local scale = 4
                local width = djui_hud_measure_text("DO NOT DELIVER THE PENGUIN") * scale
                local x = (djui_hud_get_screen_width() - width) * 0.5
                local randval = math.random(0,1)
                local height = djui_hud_get_screen_height()
                if randval == 0 then
                        djui_hud_print_text("DO NOT DELIVER THE PENGUIN", x,height/2, scale)
                end
                if gMarioStates[0].action == ACT_HOLD_IDLE or gMarioStates[0].action == ACT_HOLD_JUMP or gMarioStates[0].action == ACT_HOLD_JUMP_LAND or gMarioStates[0].action == ACT_HOLD_WALKING or gMarioStates[0].action == ACT_HOLD_BUTT_SLIDE or gMarioStates[0].action == ACT_HOLD_BUTT_SLIDE_AIR then
                        warp_to_warpnode(LEVEL_WDW, 2, 99, 241)
                end
        end
        if nearLObject == true and (gNetworkPlayers[0].currLevelNum == LEVEL_DDW) then
                djui_hud_set_font(FONT_HUD)
                djui_hud_set_resolution(RESOLUTION_DJUI)
                local scale = 4
                local width = djui_hud_measure_text("GO BACK") * scale
                local width2 = djui_hud_measure_text("IT IS NOT REAL") * scale
                local x = (djui_hud_get_screen_width() - width) * 0.5
                local x2 = (djui_hud_get_screen_width() - width2) * 0.5
                local randval = math.random(0,3)
                local height = djui_hud_get_screen_height()
                if randval == 0 then
                        djui_hud_print_text("GO BACK", x,height/2, scale)
                end
                if randval == 2 then
                        djui_hud_print_text("IT IS NOT REAL", x2,height/2, scale)
                end
        end
        if closetoLObject == true and (gNetworkPlayers[0].currLevelNum == LEVEL_DDW) then
                warp_to_level(math.random(2,38), 1, math.random(-32768, 32767))
                play_sound(SOUND_MARIO_WAAAOOOW, gMarioStates[0].pos)
        end
        if nearLObject == true and (gNetworkPlayers[0].currLevelNum == LEVEL_EERIE_HMC) then
                djui_hud_set_font(FONT_HUD)
                djui_hud_set_resolution(RESOLUTION_DJUI)
                local scale = 4
                local width = djui_hud_measure_text("GO BACK") * scale
                local width2 = djui_hud_measure_text("STOP LOOKING AT IT") * scale
                local x = (djui_hud_get_screen_width() - width) * 0.5
                local x2 = (djui_hud_get_screen_width() - width2) * 0.5
                local randval = math.random(0,3)
                local height = djui_hud_get_screen_height()
                if randval == 0 then
                        djui_hud_print_text("GO BACK", x,height/2, scale)
                end
                if randval == 2 then
                        djui_hud_print_text("STOP LOOKING AT IT", x2,height/2, scale)
                end
        end
end
hook_event(HOOK_ON_HUD_RENDER, onhudrender)
-- end
-- hook_event(HOOK_ON_WARP, warp)
-- function warp()
--     if not (gNetworkPlayers[0].currLevelNum == 6) then
--         audio_stream_stop(forestmaze)
--     end
-- end
-- hook_event(HOOK_ON_WARP, warp)
-- function idk()
--     if gNetworkPlayers[0].currActNum == 99 then
--         smlua_audio_utils_replace_sequence(0x04, 0x0E, 75, "35_Seq_custom")
--     else
        smlua_audio_utils_replace_sequence(0x04, 19, 75, "04_Seq_custom")
--     end
-- end
-- hook_event(HOOK_ON_WARP, idk)
--LEVEL_CASTLE_GIGALEAK = level_register("level_castle_entry", COURSE_NONE, "castle", "castle", 20000, 6, 6, 6)
--smlua_text_utils_course_acts_replace(LEVEL_SA, "CASTLEGROUNDS", "SEEK", "n", "I AM WATCHING", "HAHAHAHAHAHAHAHAHA", "DDDDDDDD", "GBGBGBGBGBGBGBGBGBGBGB")
--smlua_text_utils_course_acts_replace(LEVEL_ENDING, "CASTLE", "SEEK", "n", "I AM WATCHING", "HAHAHAHAHAHAHAHAHA", "DDDDDDDD", "GBGBGBGBGBGBGBGBGBGBGB")

-- on warp
function warp()
        silverStarTimerOn = false
        silverStarTimer = 0
        gPlayerSyncTable[0].maxSilverStars = 999
        gPlayerSyncTable[0].silverStars = 0
        set_override_skybox(get_skybox())
        if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == 6) then
                stop_background_music(4)
                play_music(0, 36, 1)
        end
        if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == 9) and (gNetworkPlayers[0].currAreaIndex == 1) then
                stop_background_music(2)
                --play_music(0, 37, 1)
                play_music(0, 51, 1)
        end
        if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == 24) then
                stop_background_music(2)
                play_music(0, 41, 1)
        end
        if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == 5) then
                stop_background_music(SEQ_LEVEL_SNOW)
                -- for penguin in pairs(cur_obj_find_nearest_object_with_behavior(id_bhvPenguinBaby, 5000)) do
                --         cur_obj_disable_rendering_and_become_intangible(penguin)
                -- end
                --set_override_skybox(11)
                play_music(0, 43, 1)
        end
        if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == 11) then
                stop_background_music(12)
                play_music(0, 42, 1)
                --local red_star = get_texture_info("red_star_0")
                set_override_skybox(45)
                if gMarioStates[0].playerIndex == 0 then
                        play_sound(SOUND_GENERAL_PAINTING_EJECT, gMarioStates[0].pos)
                end
                -- for obj in pairs(cur_obj_find_) do
                        
                -- end
        end
        --//if gNetworkPlayers[0].currLevelNum == 11 and (gNetworkPlayers[0].currActNum ~= 99) then
               -- set_override_skybox(BACKGROUND_UNDERWATER_CITY)
        --end
        if gNetworkPlayers[0].currActNum == 3215 and (gNetworkPlayers[0].currLevelNum == 24) then
                warp_to_level(20, 1, 0)
        end
        if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == LEVEL_PSS) then
                stop_background_music(SEQ_LEVEL_SLIDE)
                play_music(0, 44, 1)
        end
        if gNetworkPlayers[0].currActNum == 99 and (gNetworkPlayers[0].currLevelNum == 23) then
                stop_background_music(SEQ_LEVEL_WATER)
                play_music(0, 45, 1)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_FAKE_LLL then
                spawn_non_sync_object(id_bhvLies, E_MODEL_STAR, 3112, 521, 7966, nil)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_CCH then
                play_sound(SOUND_MENU_REVERSE_PAUSE, gMarioStates[0].pos)
                spawn_non_sync_object(id_bhvLies, E_MODEL_STAR, 3515, -4517, 4597, nil)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_DDW then
                spawn_non_sync_object(id_bhvLies, E_MODEL_STAR, -778, -2056, 730, nil)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_INVERTED_CASTLE_GROUNDS then
                -- play_sound(SOUND_ENV_WIND1, gMarioStates[0].pos)
                -- play_sound(SOUND_ENV_WIND2, gMarioStates[0].pos)
                spawn_non_sync_object(id_bhvWindA, E_MODEL_NONE,0,0,0,nil)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_PAINTING_WARP_TEST then
                -- play_sound(SOUND_ENV_WIND1, gMarioStates[0].pos)
                -- play_sound(SOUND_ENV_WIND2, gMarioStates[0].pos)
                spawn_non_sync_object(id_bhvWindA, E_MODEL_NONE,0,0,0,nil)
        end
        -- if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE_GIGALEAK then
        --         -- play_sound(SOUND_ENV_WIND1, gMarioStates[0].pos)
        --         -- play_sound(SOUND_ENV_WIND2, gMarioStates[0].pos)
        --         gMarioStates[0].pos.x = 0
        --         gMarioStates[0].pos.y = 1120
        --         gMarioStates[0].pos.z = 0
        -- end
        if gNetworkPlayers[0].currLevelNum == LEVEL_UD_BOB then
                spawn_non_sync_object(id_bhvWindA, E_MODEL_NONE,0,0,0,nil)
                --spawn_non_sync_object(id_bhvSilverStar, E_MODEL_STAR, -1564, -4285, -3452, nil)
                koopa = spawn_non_sync_object(id_bhvTalkingKoopa, E_MODEL_KOOPA_WITH_SHELL, -919, -4760, -3712, nil)
                koopa.oBehParams2ndByte = 113
                gPlayerSyncTable[0].maxSilverStars = 1
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_CCM and (gNetworkPlayers[0].currActNum == 100) then
                for objList = 0, NUM_OBJ_LISTS - 1 do
                        local obj = obj_get_first(objList)
                                while obj ~= nil do
                                        if obj_has_behavior_id(obj, id_bhvMario) == 0 then
                                                obj_mark_for_deletion(obj)
                                        end
                                obj = obj_get_next(obj)
                        end
                end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_BOB and (gNetworkPlayers[0].currAreaIndex == 1) and (gNetworkPlayers[0].currActNum == 99) then
                for objList = 0, NUM_OBJ_LISTS - 1 do
                        local obj = obj_get_first(objList)
                                while obj ~= nil do
                                        if obj_has_behavior_id(obj, id_bhvMario) == 0 then
                                                obj_mark_for_deletion(obj)
                                        end
                                obj = obj_get_next(obj)
                        end
                end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_PAINTING_WARP_TEST then
                gPaintingValues.wf_painting.posX = 3545.1
                gPaintingValues.wf_painting.posY = -157.99
                gPaintingValues.wf_painting.posZ = 3972.5
                gPaintingValues.wf_painting.yaw = 270
                gPlayerSyncTable[0].previouslyBeenInBigMansion = true
        else
                gPaintingValues.wf_painting.posX = -51.2
                gPaintingValues.wf_painting.posY = -204.8
                gPaintingValues.wf_painting.posZ = -4505.6
                gPaintingValues.wf_painting.yaw = 0
        end
        if gNetworkPlayers[0].currLevelNum ~= LEVEL_WF and gNetworkPlayers[0].currLevelNum ~= LEVEL_PAINTING_WARP_TEST then
                gPlayerSyncTable[0].previouslyBeenInBigMansion = false
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_WF and (gPlayerSyncTable[0].previouslyBeenInBigMansion == true) then
                warp_to_level(LEVEL_WF, 1, 3215)
                gPlayerSyncTable[0].previouslyBeenInBigMansion = false
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_EERIE_HMC then
                spawn_non_sync_object(id_bhvLies, E_MODEL_STAR, 5263.479492, -575.000000, -3048.190186, nil)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_CREEPY_JRB then
                if gPlayerSyncTable[0].eerieHMCstar == true then
                        set_mario_action(gMarioStates[0], ACT_HARD_BACKWARD_AIR_KB, 0)
                        gPlayerSyncTable[0].eerieHMCstar = false
                end
        end


        --- warp fixing
        if gNetworkPlayers[0].currLevelNum == LEVEL_BOB_Z64 then
                gMarioStates[0].pos.x = -6033
                gMarioStates[0].pos.y = 811
                gMarioStates[0].pos.z = 6078
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_EERIE_CASTLE then
                gMarioStates[0].pos.x = -1016
                gMarioStates[0].pos.y = 483
                gMarioStates[0].pos.z = 1479
                gMarioStates[0].faceAngle.y = -32768 -- -180 but for sm64
                set_mario_action(gMarioStates[0], ACT_SPAWN_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_UD_BOB then
                -- -2612, -4331, -4509
                gMarioStates[0].pos.x = -2612
                gMarioStates[0].pos.y = -4331
                gMarioStates[0].pos.z = -4509
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_EXIT_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_INVERTED_CASTLE_GROUNDS then
                -- 1300, 0, 6459
                gMarioStates[0].pos.x = 1300
                gMarioStates[0].pos.y = 0
                gMarioStates[0].pos.z = 6459
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_NO_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_DDW then
                -- -3130, 3797, -3090
                gMarioStates[0].pos.x = -3130
                gMarioStates[0].pos.y = 3797
                gMarioStates[0].pos.z = -3090
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_NO_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_FAKE_GROUNDS then
                -- -878, 537, 5138
                gMarioStates[0].pos.x = -878
                gMarioStates[0].pos.y = 537
                gMarioStates[0].pos.z = 5138
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_CCH then
                -- -1334, 2679, -1934
                gMarioStates[0].pos.x = -1334
                gMarioStates[0].pos.y = 2679
                gMarioStates[0].pos.z = -1934
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_NO_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_FAKE_LLL then
                -- -5966, 489, 6748
                gMarioStates[0].pos.x = -5966
                gMarioStates[0].pos.y = 489
                gMarioStates[0].pos.z = 6748
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_TOADS_LOBBY then
                -- 0, -84, 4052
                gMarioStates[0].pos.x = 0
                gMarioStates[0].pos.y = -84
                gMarioStates[0].pos.z = 4052
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_NO_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_PAINTING_WARP_TEST then
                -- 723, 567, 4812
                gMarioStates[0].pos.x = 723
                gMarioStates[0].pos.y = 567
                gMarioStates[0].pos.z = 4812
                gMarioStates[0].faceAngle.y = -32768
                set_mario_action(gMarioStates[0], ACT_SPAWN_NO_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_CREEPY_JRB then
                -- -6956, 1890, 691
                gMarioStates[0].pos.x = -6956
                gMarioStates[0].pos.y = 1890
                gMarioStates[0].pos.z = 691
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_NO_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_WEIRDYARD then
                -- 0, 253, 0
                gMarioStates[0].pos.x = 0
                gMarioStates[0].pos.y = 253
                gMarioStates[0].pos.z = 0
                gMarioStates[0].faceAngle.y = 0
                set_mario_action(gMarioStates[0], ACT_SPAWN_NO_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_EERIEGROUNDS then
                -- -180, -1356, 1115, 5474
                gMarioStates[0].pos.x = -1356
                gMarioStates[0].pos.y = 1115
                gMarioStates[0].pos.z = 5474
                gMarioStates[0].faceAngle.y = -32768
                set_mario_action(gMarioStates[0], ACT_SPAWN_NO_SPIN_AIRBORNE, 0)
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_EERIE_HMC then
                -- 135, -7347, 2774, 7311
                gMarioStates[0].pos.x = -7347
                gMarioStates[0].pos.y = 2774
                gMarioStates[0].pos.z = 7311
                gMarioStates[0].faceAngle.y = 24576
                set_mario_action(gMarioStates[0], ACT_SPAWN_SPIN_AIRBORNE, 0)
        end

end

-- unused
function deleteObjects(o)
        if gNetworkPlayers[0].currLevelNum == 5 and (gNetworkPlayers[0].currActNum == 100) then
                for objList = 0, NUM_OBJ_LISTS - 1 do
                        local obj = obj_get_first(objList)
                                while obj ~= nil do
                                        if not obj.behavior == id_bhvMario then
                                                obj_mark_for_deletion(obj)
                                        end
                                obj = obj_get_next(obj)
                        end
                end
        end
        if gNetworkPlayers[0].currLevelNum == 9 and (gNetworkPlayers[0].currActNum == 99) and (gNetworkPlayers[0].currAreaIndex == 1) then
                for objList = 0, NUM_OBJ_LISTS - 1 do
                        local obj = obj_get_first(objList)
                                while obj ~= nil do
                                        if not obj.behavior == id_bhvMario then
                                                obj_mark_for_deletion(obj)
                                        end
                                obj = obj_get_next(obj)
                        end
                end
        end
end

-- chat commands
function act99(msg)
        warp_to_level(gNetworkPlayers[0].currLevelNum, gNetworkPlayers[0].currAreaIndex, 99)
        return true
end
function act0(msg)
        warp_to_level(gNetworkPlayers[0].currLevelNum, gNetworkPlayers[0].currAreaIndex, 0)
        return true
end
-- function pc(msg)
--         warp_to_level(25,1,0)
--         return true
-- end
-- function eeriegrounds(msg)
--         warp_to_level(LEVEL_EERIEGROUNDS,1,0)
--         return true
-- end
-- function weirdyard(msg)
--         warp_to_level(LEVEL_WEIRDYARD,1,0)
--         return true
-- end
-- function bobz64(msg)
--         warp_to_level(LEVEL_BOB_Z64,1,0)
--         return true
-- end
-- function fakegrounds(msg)
--         warp_to_level(LEVEL_FAKE_GROUNDS,1,0)
--         return true
-- end
-- function lethal_lava_purgatory(msg)
--         warp_to_level(LEVEL_FAKE_LLL,1,0)
--         return true
-- end
-- function cch(msg)
--         warp_to_level(LEVEL_CCH,1,0)
--         return true
-- end
-- function ddw(msg)
--         warp_to_level(LEVEL_DDW,1,0)
--         return true
-- end
-- function invertedcg(msg)
--         warp_to_level(LEVEL_INVERTED_CASTLE_GROUNDS,1,0)
--         return true
-- end
-- function toadslobby(msg)
--         warp_to_level(LEVEL_TOADS_LOBBY,1,0)
--         return true
-- end
-- function udbob(msg)
--         warp_to_level(LEVEL_UD_BOB,1,0)
--         return true
-- end
function enter(msg)
        if string.lower(msg) == "udbob" then
                warp_to_level(LEVEL_UD_BOB,1,0)
        end
        if string.lower(msg) == "ddw" then
                warp_to_level(LEVEL_DDW,1,0)
        end
        if string.lower(msg) == "cch" then
                warp_to_level(LEVEL_CCH,1,0)
        end
        if string.lower(msg) == "pc" then
                warp_to_level(LEVEL_ENDING,1,0)
        end
        if string.lower(msg) == "invertedcg" then
                warp_to_level(LEVEL_INVERTED_CASTLE_GROUNDS,1,0)
        end
        if string.lower(msg) == "toadslobby" then
                warp_to_level(LEVEL_TOADS_LOBBY,1,0)
        end
        if string.lower(msg) == "llp" then
                warp_to_level(LEVEL_FAKE_LLL,1,0)
        end
        if string.lower(msg) == "eeriegrounds" then
                warp_to_level(LEVEL_EERIEGROUNDS,1,0)
        end
        if string.lower(msg) == "weirdyard" then
                warp_to_level(LEVEL_WEIRDYARD,1,0)
        end
        if string.lower(msg) == "bob.z64" then
                warp_to_level(LEVEL_BOB_Z64,1,0)
        end
        if string.lower(msg) == "fakegrounds" then
                warp_to_level(LEVEL_FAKE_GROUNDS,1,0)
        end
        if string.lower(msg) == "creepyjrb" then
                warp_to_level(LEVEL_CREEPY_JRB,1,0)
        end
        if string.lower(msg) == "bigmansion" then
                warp_to_level(LEVEL_PAINTING_WARP_TEST,1,0)
        end
        if string.lower(msg) == "eeriecastle" then
                warp_to_level(LEVEL_EERIE_CASTLE,1,0)
        end
        if string.lower(msg) == "hazycave" then
                warp_to_level(LEVEL_EERIE_HMC,1,0)
        end
        -- if string.lower(msg) == "bobombarena" then
        --         warp_to_level(LEVEL_BETA_BOB,1,0)
        -- end
        -- if string.lower(msg) == "castle" then
        --         warp_to_level(LEVEL_CASTLE_GIGALEAK,1,0)
        -- end
        return true
end
function castlegrounds(msg)
        warp_to_level(16,1,0)
        return true
end
hook_chat_command("act99", "No arguments required", act99)
hook_chat_command("act0", "No arguments required", act0)
-- hook_chat_command("pc", "No arguments required", pc)
-- hook_chat_command("eeriegrounds", "No arguments required", eeriegrounds)
-- hook_chat_command("weirdyard", "No arguments required", weirdyard)
-- hook_chat_command("bob.z64", "No arguments required", bobz64)
-- hook_chat_command("fakegrounds", "No arguments required", fakegrounds)
-- hook_chat_command("llp", "No arguments required", lethal_lava_purgatory)
-- hook_chat_command("cch", "No arguments required", cch)
-- hook_chat_command("ddw", "No arguments required", ddw)
-- hook_chat_command("invertedcg", "No arguments required", invertedcg)
-- hook_chat_command("toadslobby", "No arguments required", toadslobby)
-- hook_chat_command("udbob", "No arguments required", udbob)
hook_chat_command("enter", "[Level]", enter)
hook_chat_command("castlegrounds", "No arguments required", castlegrounds)
hook_event(HOOK_OBJECT_SET_MODEL, deleteObjects)
hook_event(HOOK_ON_WARP, warp)